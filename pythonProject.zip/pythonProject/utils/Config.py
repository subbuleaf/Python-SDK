userCredential = {
    "CLIENT_ID": "b01cea6dc87ca261",
    "SECRET_ID": "7HUO9F3KhfEU92KqtpgqQ",
    "USER_TOKEN": "98c0bea37cea4af1a73bb0179fd9a806"
}

apiBaseUrls = {

    "O_AUTH_BASE_URL": "http://oauth.taxforall.com/v2/tbsauth",

    "TBS_API_BASE_URL": "http://tbsapi.taxforall.com/v1.6.0/"
}

access_token=''

