
CREATE_BUSINESS = "Business/Create"

GET_BUSINESS = "Business/Get"