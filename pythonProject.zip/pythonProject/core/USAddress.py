usAddress = {
    "Address1": None,
    "Address2": None,
    "City": None,
    "State": None,
    "ZipCd": None

}
