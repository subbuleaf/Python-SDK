foreignAddress = {
    "Address1": "22 St",
    "Address2": "Clair Ave E",
    "City": "Toronto",
    "ProvinceOrStateNm": "Ontario",
    "Country": "CA",
    "PostalCd": "M1R 0E9"

}
