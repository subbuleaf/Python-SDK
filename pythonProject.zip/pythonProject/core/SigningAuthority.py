signingAuthority = {
    "Name": "John",
    "Phone": "1234567890",
    "BusinessMemberType": "ADMINISTRATOR"

 }
